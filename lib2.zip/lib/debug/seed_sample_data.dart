// ============================================================================
// TEMPORARY FILE — sample data so you can see the heat map + weight graph
// populated without manually tapping through the app for a year.
//
// TO REMOVE LATER:
//   1. Delete this file.
//   2. In main.dart, remove the import for this file and the one line that
//      calls `seedSampleData();`
//   3. Uninstall/reinstall the app (or clear the Hive box) to wipe the
//      sample entries it wrote to local storage — deleting the code alone
//      doesn't delete data that's already been saved on the device.
// ============================================================================

import 'package:hive/hive.dart';

void seedSampleData() {
  final box = Hive.box('workout_database');

  // only ever seed once, so re-opening the app during testing doesn't keep
  // stomping over anything real you log in the meantime.
  // bumped to V2 when the seed range changed from 30 days to a full year --
  // bump this again any time you change what gets seeded, otherwise devices
  // that already ran an older version will silently skip the new data.
  if (box.get('SAMPLE_DATA_SEEDED_V2') == true) return;
  box.put('SAMPLE_DATA_SEEDED_V2', true);

  String ddmmyyyy(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  // --------------------------------------------------------------------
  // default workout, so readFromDatabase() has something valid to load
  // (writing any key at all makes the box "non-empty", which skips the
  // app's own first-run default-data setup)
  // --------------------------------------------------------------------
  box.put('WORKOUTS', ['Upper Body']);
  box.put('EXERCISES', [
    [
      ['Bench Press', '25kg', '8', '2', 'false'],
    ],
  ]);

  // --------------------------------------------------------------------
  // heat map sample data — a full year, ending today.
  // NOTE: heat_map.dart hardcodes its visible endDate to DateTime.now(),
  // so days after today can never render no matter what's in the dataset.
  // Seeding backwards (ending today) is what actually lets you see colored
  // squares right away, and lets you scroll back through past months too.
  //
  // every "completed" day also gets a real Bench Press log entry (not just
  // a 1/0 completion flag), with the weight gradually progressing from
  // 15kg a year ago up to 25kg today — so tapping any colored day on the
  // heat map shows an actual logged set, not an empty sheet.
  // --------------------------------------------------------------------
  const totalDays = 365;
  final today = DateTime.now();

  for (int i = 0; i < totalDays; i++) {
    final date = today.subtract(Duration(days: i));
    final dateStr = ddmmyyyy(date);

    // a believable, not-every-single-day pattern (skips most multiples of
    // 5 and 7, i.e. roughly a rest day every few days)
    final completed = (i % 7 != 0 && i % 5 != 0) ? 1 : 0;
    box.put('COMPLETION_STATUS_$dateStr', completed);

    if (completed == 1) {
      // linear progression: 15kg the oldest day -> 25kg today
      final benchWeight = (15 + 10 * (totalDays - 1 - i) / (totalDays - 1)).round();
      final log = 'Upper Body|Bench Press|${benchWeight}kg|8|2';
      box.put('LOG_$dateStr', [log]);
    }
  }

  box.put('START_DATE', ddmmyyyy(today.subtract(Duration(days: totalDays))));

  // --------------------------------------------------------------------
  // bodyweight sample data — 25/06/2026 through 25/07/2026, as requested.
  // the weight graph isn't bound by "today" so this whole range shows up
  // immediately, future dates and all.
  // --------------------------------------------------------------------
  final start = DateTime(2026, 6, 25);
  final history = <String, double>{};
  double weight = 82.0;
  for (int i = 0; i <= 30; i++) {
    final date = start.add(Duration(days: i));
    weight -= 0.07; // gentle downward trend
    if (i % 4 == 0) weight += 0.3; // a little natural noise
    history[ddmmyyyy(date)] = double.parse(weight.toStringAsFixed(1));
  }
  box.put('BODYWEIGHT_HISTORY', history);
}
