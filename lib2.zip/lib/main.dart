import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'data/workout_data.dart';
import 'pages/intro_page.dart';
import 'theme/app_theme.dart';
import 'debug/seed_sample_data.dart'; // TEMPORARY — see file for removal steps

void main() async {
  // init hive
  await Hive.initFlutter();

  // open hive box
  await Hive.openBox('workout_database');

  // TEMPORARY — seeds sample data so the heat map + weight graph have
  // something to show. See lib/debug/seed_sample_data.dart for removal steps.
  seedSampleData();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => WorkoutData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const IntroPage(),
      ),
    );
  }
}